package com.example.womencare

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ── Shared live UI state (read by UI, written by Service) ─────────────────────
object AppState {
    val threatActive   = mutableStateOf(false)
    val connStatus     = mutableStateOf("🔴 Connecting...")
    val firebaseState  = mutableStateOf("Waiting...")
    val gpsText        = mutableStateOf("No GPS yet")
    val secondsElapsed = mutableIntStateOf(0)
    val audioUploads   = mutableIntStateOf(0)
    val imageUploads   = mutableIntStateOf(0)
    val lastUpload     = mutableStateOf("None yet")
    val logs           = mutableStateListOf<String>()

    fun addLog(msg: String) {
        val t = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        logs.add(0, "[$t] $msg")
        if (logs.size > 80) logs.removeAt(logs.lastIndex)
    }
}

// ── MainActivity — ONLY shows UI, starts service ──────────────────────────────
class MainActivity : ComponentActivity() {

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        if (perms.values.all { it }) {
            SafetyForegroundService.start(this)
            AppState.addLog("✅ Permissions granted — service started")
        } else {
            AppState.addLog("❌ Permissions denied — grant in Settings")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { SafetyDashboard() } }
        requestPermissionsAndStart()
    }

    private fun requestPermissionsAndStart() {
        val needed = arrayOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.CAMERA
        )
        val missing = needed.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) {
            // All permissions already granted — start service immediately
            SafetyForegroundService.start(this)
            AppState.addLog("🚀 Service started — monitoring Firebase")
        } else {
            permLauncher.launch(missing.toTypedArray())
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// UI Colors
// ─────────────────────────────────────────────────────────────────────────────
val DarkBg     = Color(0xFF060910)
val CardBg     = Color(0xFF0E1320)
val SafeGreen  = Color(0xFF00E676)
val DangerRed  = Color(0xFFFF1744)
val AccentPink = Color(0xFFFF4081)
val AccentBlue = Color(0xFF448AFF)
val TextPri    = Color(0xFFF0F0F5)
val TextMuted  = Color(0xFF6B7280)

@Composable
fun SafetyDashboard() {
    val threatActive by AppState.threatActive
    val connStatus   by AppState.connStatus
    val fbState      by AppState.firebaseState
    val gpsText      by AppState.gpsText
    val seconds      by AppState.secondsElapsed
    val lastUpload   by AppState.lastUpload
    val audioUps     by AppState.audioUploads
    val imageUps     by AppState.imageUploads
    val logs         = AppState.logs

    Column(Modifier.fillMaxSize().background(DarkBg)) {

        // ── Header ────────────────────────────────────────────────────────────
        Column(
            modifier            = Modifier.fillMaxWidth().background(CardBg).padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("🛡️ Women Safety", fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold, color = TextPri)
            Text("Guardian always running in background",
                fontSize = 11.sp, color = TextMuted)
            Spacer(Modifier.height(8.dp))

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ChipCard(Modifier.weight(1f), connStatus,
                    if (connStatus.contains("🟢")) SafeGreen else DangerRed)
                ChipCard(Modifier.weight(1f), fbState,
                    if (fbState.contains("TRUE")) DangerRed else SafeGreen)
            }

            Spacer(Modifier.height(10.dp))

            Box(
                modifier = Modifier.fillMaxWidth()
                    .background(
                        if (threatActive) DangerRed.copy(alpha = 0.2f)
                        else SafeGreen.copy(alpha = 0.12f),
                        RoundedCornerShape(14.dp)
                    ).padding(14.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text       = if (threatActive) "🚨 THREAT DETECTED" else "✅ SYSTEM SAFE",
                        fontSize   = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color      = if (threatActive) DangerRed else SafeGreen
                    )
                    if (threatActive)
                        Text("Active: ${fmtSec(seconds)}", fontSize = 13.sp,
                            color = DangerRed.copy(alpha = 0.8f))
                }
            }

            Spacer(Modifier.height(10.dp))

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatBox(Modifier.weight(1f), "🎤", "Audio",  "$audioUps clips")
                StatBox(Modifier.weight(1f), "📸", "Photos", "$imageUps imgs")
                StatBox(Modifier.weight(1f), "⏱️", "Timer",  fmtSec(seconds))
            }

            Spacer(Modifier.height(8.dp))
            InfoLine("📍 GPS",    gpsText,    SafeGreen)
            Spacer(Modifier.height(4.dp))
            InfoLine("☁️ Upload", lastUpload, AccentPink)
        }

        // ── Live Log ──────────────────────────────────────────────────────────
        Column(
            modifier = Modifier.fillMaxWidth().weight(1f)
                .background(Color(0xFF04060C)).padding(12.dp)
        ) {
            Row(Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment     = Alignment.CenterVertically
            ) {
                Text("📋 Live Log", fontSize = 13.sp,
                    fontWeight = FontWeight.Bold, color = AccentBlue)
                Text("${logs.size} events", fontSize = 11.sp, color = TextMuted)
            }
            Spacer(Modifier.height(6.dp))

            if (logs.isEmpty()) {
                Box(Modifier.fillMaxWidth().padding(20.dp), Alignment.Center) {
                    Text("Waiting for events...", color = TextMuted, fontSize = 12.sp)
                }
            } else {
                LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    items(logs) { log ->
                        val c = when {
                            log.contains("❌") -> DangerRed
                            log.contains("🚨") -> DangerRed
                            log.contains("✅") -> SafeGreen
                            log.contains("📡") -> AccentBlue
                            log.contains("☁️") || log.contains("⬆️") -> Color(0xFF29B6F6)
                            log.contains("📍") -> Color(0xFF66BB6A)
                            log.contains("🎤") -> Color(0xFFAB47BC)
                            log.contains("📸") -> Color(0xFFFF7043)
                            log.contains("⚠️") || log.contains("⏳") -> Color(0xFFFFB300)
                            else -> TextPri.copy(alpha = 0.75f)
                        }
                        Text(log, color = c, fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.fillMaxWidth()
                                .background(CardBg.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 8.dp, vertical = 3.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun ChipCard(modifier: Modifier, text: String, color: Color) {
    Box(
        modifier         = modifier
            .background(color.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = color, fontSize = 11.sp, maxLines = 1) }
}

@Composable
fun StatBox(modifier: Modifier, icon: String, label: String, value: String) {
    Column(
        modifier            = modifier
            .background(Color(0xFF0A0F1A), RoundedCornerShape(10.dp)).padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(icon,  fontSize = 20.sp)
        Text(value, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = AccentPink)
        Text(label, fontSize = 10.sp, color = TextMuted)
    }
}

@Composable
fun InfoLine(label: String, value: String, color: Color) {
    Row(
        modifier              = Modifier.fillMaxWidth()
            .background(Color(0xFF080C16), RoundedCornerShape(8.dp))
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment     = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = TextMuted, fontSize = 11.sp)
        Text(value, color = color,     fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}

fun fmtSec(s: Int) = if (s >= 60) "${s / 60}m ${s % 60}s" else "${s}s"