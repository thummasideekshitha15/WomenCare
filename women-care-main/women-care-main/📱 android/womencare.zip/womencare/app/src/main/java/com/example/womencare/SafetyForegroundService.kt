package com.example.womencare

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.ImageFormat
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.location.Location
import android.media.ImageReader
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import com.amazonaws.auth.BasicAWSCredentials
import com.amazonaws.mobileconnectors.s3.transferutility.TransferListener
import com.amazonaws.mobileconnectors.s3.transferutility.TransferService
import com.amazonaws.mobileconnectors.s3.transferutility.TransferState
import com.amazonaws.mobileconnectors.s3.transferutility.TransferUtility
import com.amazonaws.regions.Region
import com.amazonaws.regions.Regions
import com.amazonaws.services.s3.AmazonS3Client
import com.amazonaws.services.s3.model.CannedAccessControlList
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

class SafetyForegroundService : Service() {

    companion object {
        const val CHANNEL_ID   = "women_safety_channel"
        const val NOTIF_ID     = 101
        const val ACTION_START = "START_SAFETY"
        const val ACTION_STOP  = "STOP_SAFETY"

        // ── TIMING SETTINGS ───────────────────────────────────────────────────
        const val AUDIO_CLIP_MS   = 10_000L   // 10 seconds per audio clip
        const val FRONT_PHOTO_MS  = 15_000L   // front photo every 15 seconds
        const val BACK_PHOTO_MS   = 15_000L   // back photo 15s AFTER front = 30s total gap
        const val GPS_INTERVAL_MS = 300_000L  // GPS every 5 minutes (300,000ms)
        // ─────────────────────────────────────────────────────────────────────

        fun start(context: Context) {
            val intent = Intent(context, SafetyForegroundService::class.java)
                .setAction(ACTION_START)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                context.startForegroundService(intent)
            else
                context.startService(intent)
        }

        fun stop(context: Context) {
            context.startService(
                Intent(context, SafetyForegroundService::class.java).setAction(ACTION_STOP)
            )
        }
    }

    // ── AWS ───────────────────────────────────────────────────────────────────
    private val accessKey  = "AKIA3ISBWDBGMOUQK5OM"
    private val secretKey  = "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"
    private val bucketName = "women-care"
    private val awsRegion  = Regions.EU_NORTH_1

    private val db by lazy { Firebase.database.reference }

    @Suppress("DEPRECATION")
    private lateinit var s3: AmazonS3Client
    private lateinit var transferUtil: TransferUtility
    private lateinit var fusedLocation: FusedLocationProviderClient

    private var currentLocation: Location? = null
    private var mediaRecorder: MediaRecorder? = null
    private var currentAudioFile: File? = null
    private var isRecording       = false
    private var isCurrentlyThreat = false

    private val frontCamThread  = HandlerThread("FrontCamThread").also { it.start() }
    private val backCamThread   = HandlerThread("BackCamThread").also  { it.start() }
    private val frontCamHandler = Handler(frontCamThread.looper)
    private val backCamHandler  = Handler(backCamThread.looper)
    private val mainHandler     = Handler(Looper.getMainLooper())
    private val cameraInUse     = AtomicBoolean(false)

    // Separate runnables for each independent timer
    private var audioRunnable:   Runnable? = null
    private var photoRunnable:   Runnable? = null
    private var gpsRunnable:     Runnable? = null
    private var secondsRunnable: Runnable? = null

    // ── Lifecycle ─────────────────────────────────────────────────────────────
    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val creds = BasicAWSCredentials(accessKey, secretKey)
        @Suppress("DEPRECATION")
        s3 = AmazonS3Client(creds)
        s3.setRegion(Region.getRegion(awsRegion))
        transferUtil = TransferUtility.builder()
            .context(applicationContext)
            .s3Client(s3)
            .build()
        applicationContext.startService(
            Intent(applicationContext, TransferService::class.java)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            AppState.addLog("🛑 Service stopped")
            stopSelf()
            return START_NOT_STICKY
        }
        startForeground(NOTIF_ID, buildNotification("👀 Monitoring — waiting for threat signal"))
        AppState.addLog("🛡️ Foreground service started")
        startLocationUpdates()
        listenToFirebase()
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        // Auto-restart if swiped away
        val i = Intent(applicationContext, SafetyForegroundService::class.java)
            .setAction(ACTION_START)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            startForegroundService(i) else startService(i)
        AppState.addLog("🔄 Service restarted after swipe")
    }

    override fun onDestroy() {
        super.onDestroy()
        stopThreatMode()
        frontCamThread.quitSafely()
        backCamThread.quitSafely()
    }

    // ── Notification ──────────────────────────────────────────────────────────
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel(
                CHANNEL_ID, "Women Safety Monitor",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps safety monitoring alive in background"
                setShowBadge(false)
                getSystemService(NotificationManager::class.java).createNotificationChannel(this)
            }
        }
    }

    private fun buildNotification(text: String): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("🛡️ Women Safety")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(pi)
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
    }

    // ── Firebase ──────────────────────────────────────────────────────────────
    private fun listenToFirebase() {
        AppState.connStatus.value = "🟡 Connecting..."
        db.child("threat_detect/state")
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snap: DataSnapshot) {
                    val active = snap.getValue(Boolean::class.java) ?: false
                    AppState.connStatus.value    = "🟢 Firebase Connected"
                    AppState.firebaseState.value = if (active) "🚨 state=TRUE" else "✅ state=FALSE"
                    AppState.addLog("📡 Firebase → state = $active")

                    if (active && !isCurrentlyThreat) {
                        isCurrentlyThreat = true
                        AppState.threatActive.value = true
                        updateNotification("🚨 THREAT — Recording active")
                        AppState.addLog("🚨 THREAT ON")
                        startThreatMode()
                    } else if (!active && isCurrentlyThreat) {
                        isCurrentlyThreat = false
                        AppState.threatActive.value = false
                        updateNotification("✅ Threat cleared — monitoring")
                        AppState.addLog("✅ Threat cleared")
                        stopThreatMode()
                    }
                }
                override fun onCancelled(e: DatabaseError) {
                    AppState.connStatus.value = "🔴 DB Error"
                    AppState.addLog("❌ Firebase: ${e.message}")
                }
            })
    }

    // ── Threat Mode — 3 INDEPENDENT timers ───────────────────────────────────
    private fun startThreatMode() {
        AppState.secondsElapsed.intValue = 0
        AppState.audioUploads.intValue   = 0
        AppState.imageUploads.intValue   = 0
        db.child("threat_detect/session_start").setValue(timestamp())
        startSecondCounter()

        // Timer 1: Audio — every 10 seconds
        startAudioLoop()
        AppState.addLog("🎤 Audio loop: every 10s")

        // Timer 2: Photos — front at 0s, back at 15s, repeat every 30s
        startPhotoLoop()
        AppState.addLog("📸 Photo loop: front@0s, back@15s, repeat every 30s")

        // Timer 3: GPS — every 5 minutes
        startGpsLoop()
        AppState.addLog("📍 GPS loop: every 5 minutes")
    }

    private fun stopThreatMode() {
        audioRunnable?.let   { mainHandler.removeCallbacks(it) }
        photoRunnable?.let   { mainHandler.removeCallbacks(it) }
        gpsRunnable?.let     { mainHandler.removeCallbacks(it) }
        stopSecondCounter()
        stopCurrentRecording(upload = true)
        AppState.addLog("🛑 All timers stopped")
    }

    // ── Audio Loop (every 10s) ────────────────────────────────────────────────
    private fun startAudioLoop() {
        // Start first clip immediately
        stopCurrentRecording(upload = false)
        startNewRecording()

        audioRunnable = object : Runnable {
            override fun run() {
                if (!isCurrentlyThreat) return
                // Stop current 10s clip → upload → start new one
                stopCurrentRecording(upload = true)
                startNewRecording()
                AppState.addLog("🎤 New 10s clip started")
                mainHandler.postDelayed(this, AUDIO_CLIP_MS)
            }
        }
        mainHandler.postDelayed(audioRunnable!!, AUDIO_CLIP_MS)
    }

    // ── Photo Loop (front@0s, back@15s, repeat every 30s) ────────────────────
    private fun startPhotoLoop() {
        // Front photo immediately
        captureFront()

        // Back photo 15s after front
        mainHandler.postDelayed({ captureBack() }, FRONT_PHOTO_MS)

        // Repeat the whole cycle every 30s
        photoRunnable = object : Runnable {
            override fun run() {
                if (!isCurrentlyThreat) return
                AppState.addLog("📸 Photo cycle — front now, back in 15s")
                captureFront()
                mainHandler.postDelayed({ captureBack() }, FRONT_PHOTO_MS)
                mainHandler.postDelayed(this, FRONT_PHOTO_MS + BACK_PHOTO_MS)  // 30s total
            }
        }
        mainHandler.postDelayed(photoRunnable!!, FRONT_PHOTO_MS + BACK_PHOTO_MS)
    }

    // ── GPS Loop (every 5 minutes) ────────────────────────────────────────────
    private fun startGpsLoop() {
        // Send GPS immediately on threat
        pushGpsToFirebase()

        gpsRunnable = object : Runnable {
            override fun run() {
                if (!isCurrentlyThreat) return
                pushGpsToFirebase()
                mainHandler.postDelayed(this, GPS_INTERVAL_MS)
            }
        }
        mainHandler.postDelayed(gpsRunnable!!, GPS_INTERVAL_MS)
    }

    // ── Audio Recording ───────────────────────────────────────────────────────
    private fun startNewRecording() {
        try {
            val file = File(filesDir, "audio_${System.currentTimeMillis()}.mp3")
            mediaRecorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
                MediaRecorder(this)
            else @Suppress("DEPRECATION") MediaRecorder()

            mediaRecorder!!.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setOutputFile(file.absolutePath)
                prepare()
                start()
            }
            currentAudioFile = file
            isRecording = true
            AppState.addLog("🎤 Recording started (10s clip)")
        } catch (e: Exception) {
            AppState.addLog("❌ Audio start: ${e.message}")
        }
    }

    private fun stopCurrentRecording(upload: Boolean) {
        try {
            if (isRecording) {
                try { mediaRecorder?.stop() } catch (_: Exception) {}
                mediaRecorder?.release()
                mediaRecorder = null
                isRecording = false
                if (upload) currentAudioFile?.let {
                    AppState.addLog("☁️ Uploading 10s audio → S3")
                    uploadToS3(it, "recordings")
                }
            }
        } catch (e: Exception) {
            AppState.addLog("❌ Audio stop: ${e.message}")
        }
    }

    // ── Camera ────────────────────────────────────────────────────────────────
    private fun captureFront() {
        if (!cameraInUse.compareAndSet(false, true)) {
            AppState.addLog("⚠️ Camera busy — skipping front")
            return
        }
        captureWithCamera2(front = true, handler = frontCamHandler) {
            cameraInUse.set(false)
        }
    }

    private fun captureBack() {
        if (!cameraInUse.compareAndSet(false, true)) {
            mainHandler.postDelayed({ captureBack() }, 500)
            return
        }
        captureWithCamera2(front = false, handler = backCamHandler) {
            cameraInUse.set(false)
        }
    }

    private fun captureWithCamera2(front: Boolean, handler: Handler, onDone: () -> Unit) {
        val label = if (front) "front" else "back"
        val file  = File(filesDir, "${label}_${System.currentTimeMillis()}.jpg")
        try {
            val manager  = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = manager.cameraIdList
                .filter { it.length == 1 }
                .firstOrNull { id ->
                    val facing = manager.getCameraCharacteristics(id)
                        .get(CameraCharacteristics.LENS_FACING)
                    if (front) facing == CameraCharacteristics.LENS_FACING_FRONT
                    else       facing == CameraCharacteristics.LENS_FACING_BACK
                }
            if (cameraId == null) {
                AppState.addLog("⚠️ No $label camera")
                onDone(); return
            }

            val imageReader = ImageReader.newInstance(1280, 720, ImageFormat.JPEG, 2)
            imageReader.setOnImageAvailableListener({ reader ->
                val image = reader.acquireNextImage()
                if (image == null) { onDone(); return@setOnImageAvailableListener }
                try {
                    val buffer: ByteBuffer = image.planes[0].buffer
                    val bytes = ByteArray(buffer.remaining())
                    buffer.get(bytes)
                    image.close()
                    FileOutputStream(file).use { it.write(bytes) }
                    mainHandler.post {
                        AppState.addLog("📸 $label (${bytes.size / 1024}KB) → uploading")
                        uploadToS3(file, "photos")
                    }
                } catch (e: Exception) {
                    try { image.close() } catch (_: Exception) {}
                    mainHandler.post { AppState.addLog("❌ $label save: ${e.message}") }
                } finally {
                    onDone(); reader.close()
                }
            }, handler)

            @Suppress("MissingPermission")
            manager.openCamera(cameraId, object : CameraDevice.StateCallback() {
                override fun onOpened(camera: CameraDevice) {
                    try {
                        val req = camera.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
                            .also { it.addTarget(imageReader.surface) }
                        @Suppress("DEPRECATION")
                        camera.createCaptureSession(
                            listOf(imageReader.surface),
                            object : CameraCaptureSession.StateCallback() {
                                override fun onConfigured(s: CameraCaptureSession) {
                                    try {
                                        s.capture(req.build(), null, handler)
                                        mainHandler.postDelayed({
                                            try { camera.close() } catch (_: Exception) {}
                                        }, 1000)
                                    } catch (e: Exception) {
                                        try { camera.close() } catch (_: Exception) {}
                                        mainHandler.post { AppState.addLog("❌ $label capture: ${e.message}") }
                                        onDone()
                                    }
                                }
                                override fun onConfigureFailed(s: CameraCaptureSession) {
                                    try { camera.close() } catch (_: Exception) {}
                                    mainHandler.post { AppState.addLog("❌ $label config failed") }
                                    onDone()
                                }
                            }, handler
                        )
                    } catch (e: Exception) {
                        try { camera.close() } catch (_: Exception) {}
                        mainHandler.post { AppState.addLog("❌ $label session: ${e.message}") }
                        onDone()
                    }
                }
                override fun onDisconnected(c: CameraDevice) { c.close(); onDone() }
                override fun onError(c: CameraDevice, e: Int) {
                    c.close()
                    mainHandler.post { AppState.addLog("❌ $label error: $e") }
                    onDone()
                }
            }, handler)
        } catch (e: Exception) {
            mainHandler.post { AppState.addLog("❌ Camera2 ($label): ${e.message}") }
            onDone()
        }
    }

    // ── GPS ───────────────────────────────────────────────────────────────────
    private fun startLocationUpdates() {
        fusedLocation = LocationServices.getFusedLocationProviderClient(this)
        val req = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 60_000L)
            .setMinUpdateIntervalMillis(30_000L)
            .build()
        try {
            fusedLocation.requestLocationUpdates(req, object : LocationCallback() {
                override fun onLocationResult(result: LocationResult) {
                    currentLocation = result.lastLocation
                    result.lastLocation?.let {
                        AppState.gpsText.value =
                            "${"%.5f".format(it.latitude)}, ${"%.5f".format(it.longitude)}"
                    }
                }
            }, Looper.getMainLooper())
            AppState.addLog("📍 GPS listener active")
        } catch (e: SecurityException) {
            AppState.addLog("❌ GPS permission denied")
        }
    }

    private fun pushGpsToFirebase() {
        currentLocation?.let { loc ->
            db.child("threat_detect/live_location").setValue(mapOf(
                "lat"       to loc.latitude,
                "lng"       to loc.longitude,
                "accuracy"  to loc.accuracy,
                "timestamp" to timestamp(),
                "maps_link" to "https://maps.google.com/?q=${loc.latitude},${loc.longitude}"
            ))
            AppState.addLog("📍 GPS → Firebase: ${AppState.gpsText.value}")
        } ?: AppState.addLog("⚠️ GPS not ready")
    }

    // ── Second Counter ────────────────────────────────────────────────────────
    private fun startSecondCounter() {
        secondsRunnable = object : Runnable {
            override fun run() {
                if (!isCurrentlyThreat) return
                AppState.secondsElapsed.intValue++
                db.child("threat_detect/seconds_active")
                    .setValue(AppState.secondsElapsed.intValue)
                mainHandler.postDelayed(this, 1000)
            }
        }
        mainHandler.post(secondsRunnable!!)
    }

    private fun stopSecondCounter() {
        secondsRunnable?.let { mainHandler.removeCallbacks(it) }
    }

    // ── S3 Upload ─────────────────────────────────────────────────────────────
    private fun uploadToS3(file: File, folder: String) {
        if (!file.exists()) { AppState.addLog("⚠️ Missing: ${file.name}"); return }
        val s3Key = "$folder/${file.name}"
        transferUtil.upload(bucketName, s3Key, file, CannedAccessControlList.PublicRead)
            .setTransferListener(object : TransferListener {
                override fun onStateChanged(id: Int, state: TransferState?) {
                    if (state == TransferState.COMPLETED) {
                        val url = "https://$bucketName.s3.eu-north-1.amazonaws.com/$s3Key"
                        val ts  = System.currentTimeMillis()
                        if (folder == "recordings") {
                            db.child("threat_detect/uploads/audio/$ts").setValue(url)
                            db.child("threat_detect/latest_audio").setValue(url)
                            mainHandler.post {
                                AppState.audioUploads.intValue++
                                AppState.lastUpload.value = "🎤 ${timestamp()}"
                                AppState.addLog("✅ Audio → S3 ✓")
                            }
                        } else {
                            db.child("threat_detect/uploads/photos/$ts").setValue(url)
                            db.child("threat_detect/latest_photo").setValue(url)
                            mainHandler.post {
                                AppState.imageUploads.intValue++
                                AppState.lastUpload.value = "📸 ${timestamp()}"
                                AppState.addLog("✅ Photo → S3 ✓")
                            }
                        }
                        db.child("threat_detect/last_upload_time").setValue(timestamp())
                        file.delete()
                    }
                }
                override fun onProgressChanged(id: Int, current: Long, total: Long) {}
                override fun onError(id: Int, ex: Exception?) {
                    mainHandler.post { AppState.addLog("❌ S3: ${ex?.message}") }
                }
            })
    }

    private fun timestamp() =
        SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
}