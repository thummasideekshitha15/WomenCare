import { useState, useEffect } from 'react';
import { Camera, Mic, Clock, Upload } from 'lucide-react';
import type { FirebaseData } from '@/hooks/useFirebaseData';
import { timeAgo } from '@/lib/formatTime';

interface Props {
  data: FirebaseData;
}

export function StatsFooter({ data }: Props) {
  const [elapsed, setElapsed] = useState(data.seconds_active);
  const [, setTick] = useState(0);

  useEffect(() => {
    setElapsed(data.seconds_active);
    if (!data.state) return;
    const id = setInterval(() => setElapsed(s => s + 1), 1000);
    return () => clearInterval(id);
  }, [data.seconds_active, data.state]);

  // Force re-render for timeAgo
  useEffect(() => {
    const id = setInterval(() => setTick(t => t + 1), 5000);
    return () => clearInterval(id);
  }, []);

  const photoCount = data.uploads?.photos ? Object.keys(data.uploads.photos).length : 0;
  const audioCount = data.uploads?.audio ? Object.keys(data.uploads.audio).length : 0;

  const formatDuration = (s: number) => {
    const h = Math.floor(s / 3600).toString().padStart(2, '0');
    const m = Math.floor((s % 3600) / 60).toString().padStart(2, '0');
    const sec = (s % 60).toString().padStart(2, '0');
    return `${h}:${m}:${sec}`;
  };

  const stats = [
    { icon: Camera, label: 'Photos Captured', value: photoCount.toString(), emoji: '📸' },
    { icon: Mic, label: 'Audio Clips', value: audioCount.toString(), emoji: '🎤' },
    { icon: Clock, label: 'Session Duration', value: formatDuration(elapsed), emoji: '⏱' },
    { icon: Upload, label: 'Last Upload', value: timeAgo(data.last_upload_time), emoji: '🕐' },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
      {stats.map((s) => (
        <div key={s.label} className="border border-border rounded-lg bg-card p-3 text-center">
          <p className="text-xs text-muted-foreground mb-1">{s.emoji} {s.label}</p>
          <p className="text-xl font-bold font-mono text-foreground">{s.value}</p>
        </div>
      ))}
    </div>
  );
}
