import { useState, useEffect } from 'react';
import { Shield, RefreshCw, FileText } from 'lucide-react';
import type { FirebaseData } from '@/hooks/useFirebaseData';

interface Props {
  data: FirebaseData | null;
  onRefresh: () => void;
  onExport: () => void;
}

export function DashboardHeader({ data, onRefresh, onExport }: Props) {
  const [clock, setClock] = useState('');

  useEffect(() => {
    const tick = () => {
      setClock(
        new Date().toLocaleString('en-IN', {
          timeZone: 'Asia/Kolkata',
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
          hour12: true,
          day: '2-digit',
          month: 'short',
          year: 'numeric',
        })
      );
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);

  return (
    <header className="flex items-center justify-between px-4 md:px-6 py-3 bg-secondary border-b border-border">
      <div className="flex items-center gap-3">
        <div className="w-9 h-9 rounded-lg bg-police flex items-center justify-center">
          <Shield className="w-5 h-5 text-police-foreground" />
        </div>
        <div>
          <h1 className="text-base md:text-lg font-bold tracking-wide text-foreground">
            DISHA SMART MONITOR
          </h1>
          <p className="text-xs text-muted-foreground hidden sm:block">Women Safety Emergency Dashboard</p>
        </div>
      </div>

      <div className="flex items-center gap-3 md:gap-4">
        {data?.state && (
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-danger/20 border border-danger/40">
            <span className="w-2 h-2 rounded-full bg-danger animate-pulse-dot" />
            <span className="text-xs font-semibold text-danger">LIVE</span>
          </div>
        )}
        <span className="text-xs md:text-sm font-mono text-muted-foreground">{clock}</span>
        <button
          onClick={onRefresh}
          className="p-2 rounded-md hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
          title="Refresh Now"
        >
          <RefreshCw className="w-4 h-4" />
        </button>
        <button
          onClick={onExport}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-police text-police-foreground text-xs font-medium hover:opacity-90 transition-opacity"
        >
          <FileText className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Export Evidence</span>
        </button>
      </div>
    </header>
  );
}
