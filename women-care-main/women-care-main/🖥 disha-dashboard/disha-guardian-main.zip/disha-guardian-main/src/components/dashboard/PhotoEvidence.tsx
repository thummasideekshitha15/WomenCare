import { useState, useEffect, useRef } from 'react';
import { Camera, Copy, X, Check } from 'lucide-react';
import type { FirebaseData } from '@/hooks/useFirebaseData';
import { formatIST } from '@/lib/formatTime';

interface Props {
  data: FirebaseData;
  isNew: boolean;
}

export function PhotoEvidence({ data, isNew }: Props) {
  const [lightbox, setLightbox] = useState<string | null>(null);
  const [copiedUrl, setCopiedUrl] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  const photos = data.uploads?.photos
    ? Object.entries(data.uploads.photos).sort((a, b) => b[0].localeCompare(a[0]))
    : [];

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollLeft = 0;
    }
  }, [photos.length]);

  const copyUrl = async (url: string, e: React.MouseEvent) => {
    e.stopPropagation();
    await navigator.clipboard.writeText(url);
    setCopiedUrl(url);
    setTimeout(() => setCopiedUrl(null), 2000);
  };

  if (!data.latest_photo && photos.length === 0) {
    return (
      <div className="border border-border rounded-lg bg-card p-4 h-full flex flex-col">
        <h3 className="text-sm font-semibold text-muted-foreground flex items-center gap-2 mb-3">
          <Camera className="w-4 h-4" /> PHOTO EVIDENCE
        </h3>
        <div className="flex-1 flex items-center justify-center bg-muted rounded-md min-h-[200px]">
          <div className="text-center text-muted-foreground">
            <Camera className="w-10 h-10 mx-auto mb-2 opacity-30" />
            <p className="text-sm">Awaiting first capture...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`border rounded-lg bg-card p-4 flex flex-col ${data.state ? 'animate-pulse-danger border-danger/30' : 'border-border'}`}>
      <h3 className="text-sm font-semibold text-muted-foreground flex items-center gap-2 mb-3">
        <Camera className="w-4 h-4" /> PHOTO EVIDENCE
        {isNew && (
          <span className="ml-2 px-2 py-0.5 rounded text-xs font-bold bg-safe/20 text-safe border border-safe/30">
            New Evidence
          </span>
        )}
      </h3>

      {/* Latest photo */}
      {data.latest_photo && (
        <div
          className={`relative rounded-md overflow-hidden mb-3 cursor-pointer ${isNew ? 'animate-flash-green' : ''}`}
          onClick={() => setLightbox(data.latest_photo)}
        >
          <img
            src={data.latest_photo}
            alt="Latest Capture"
            className="w-full max-h-[300px] object-cover rounded-md"
            loading="eager"
          />
          <span className="absolute top-2 left-2 px-2 py-1 rounded text-xs font-medium bg-card/80 text-foreground backdrop-blur-sm">
            Latest Capture
          </span>
        </div>
      )}

      {/* Photo timeline */}
      {photos.length > 0 && (
        <div ref={scrollRef} className="flex gap-2 overflow-x-auto pb-2 mt-1">
          {photos.map(([ts, url]) => (
            <div
              key={ts}
              className="relative flex-shrink-0 w-24 h-24 rounded-md overflow-hidden cursor-pointer group border border-border hover:border-police/50 transition-colors"
              onClick={() => setLightbox(url)}
            >
              <img src={url} alt={ts} className="w-full h-full object-cover" loading="lazy" />
              <div className="absolute bottom-0 inset-x-0 bg-card/80 backdrop-blur-sm px-1 py-0.5">
                <p className="text-[10px] text-muted-foreground truncate">{formatIST(ts)}</p>
              </div>
              <button
                onClick={(e) => copyUrl(url, e)}
                className="absolute top-1 right-1 p-1 rounded bg-card/80 text-muted-foreground hover:text-foreground opacity-0 group-hover:opacity-100 transition-opacity"
                title="Copy URL"
              >
                {copiedUrl === url ? <Check className="w-3 h-3 text-safe" /> : <Copy className="w-3 h-3" />}
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Lightbox */}
      {lightbox && (
        <div
          className="fixed inset-0 z-50 bg-background/90 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setLightbox(null)}
        >
          <button
            className="absolute top-4 right-4 p-2 rounded-full bg-card text-foreground hover:bg-muted"
            onClick={() => setLightbox(null)}
          >
            <X className="w-6 h-6" />
          </button>
          <img
            src={lightbox}
            alt="Evidence fullscreen"
            className="max-w-full max-h-[90vh] rounded-lg shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}
    </div>
  );
}
