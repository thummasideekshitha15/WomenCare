import { MapPin, ExternalLink, Crosshair } from 'lucide-react';
import type { FirebaseData } from '@/hooks/useFirebaseData';
import { formatIST } from '@/lib/formatTime';

interface Props {
  data: FirebaseData;
}

export function LiveLocation({ data }: Props) {
  const loc = data.live_location;

  const accuracyColor = (acc: number) => {
    if (acc < 20) return 'text-safe';
    if (acc <= 100) return 'text-alert';
    return 'text-danger';
  };

  if (!loc) {
    return (
      <div className="border border-border rounded-lg bg-card p-4 h-full flex flex-col">
        <h3 className="text-sm font-semibold text-muted-foreground flex items-center gap-2 mb-3">
          <MapPin className="w-4 h-4" /> LIVE LOCATION
        </h3>
        <div className="flex-1 flex items-center justify-center bg-muted rounded-md">
          <div className="text-center text-muted-foreground">
            <Crosshair className="w-10 h-10 mx-auto mb-2 opacity-30" />
            <p className="text-sm">Awaiting GPS signal...</p>
          </div>
        </div>
      </div>
    );
  }

  const mapEmbedUrl = `https://www.google.com/maps?q=${loc.lat},${loc.lng}&output=embed`;

  return (
    <div className={`border rounded-lg bg-card p-4 flex flex-col ${data.state ? 'animate-pulse-danger border-danger/30' : 'border-border'}`}>
      <h3 className="text-sm font-semibold text-muted-foreground flex items-center gap-2 mb-3">
        <MapPin className="w-4 h-4" /> LIVE LOCATION
      </h3>
      <div className="rounded-md overflow-hidden mb-3 aspect-video">
        <iframe
          src={mapEmbedUrl}
          className="w-full h-full border-0"
          allowFullScreen
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
          title="Live Location Map"
        />
      </div>
      <div className="space-y-2">
        <div className="font-mono text-lg text-foreground">
          {loc.lat.toFixed(6)}, {loc.lng.toFixed(6)}
        </div>
        <div className="flex items-center gap-4 text-xs">
          <span className={accuracyColor(loc.accuracy)}>
            ◉ Accuracy: {loc.accuracy.toFixed(1)}m
          </span>
          <span className="text-muted-foreground">
            GPS fix: {formatIST(loc.timestamp)}
          </span>
        </div>
        {loc.maps_link && (
          <a
            href={loc.maps_link}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 mt-2 px-4 py-2 rounded-md bg-police text-police-foreground text-sm font-medium hover:opacity-90 transition-opacity"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            Open Full Map
          </a>
        )}
      </div>
    </div>
  );
}
