import { useState, useEffect } from 'react';
import { ShieldAlert, ShieldCheck } from 'lucide-react';
import type { FirebaseData } from '@/hooks/useFirebaseData';
import { formatIST } from '@/lib/formatTime';

interface Props {
  data: FirebaseData;
}

export function ThreatBanner({ data }: Props) {
  const [elapsed, setElapsed] = useState(data.seconds_active);

  useEffect(() => {
    setElapsed(data.seconds_active);
    if (!data.state) return;
    const id = setInterval(() => setElapsed(s => s + 1), 1000);
    return () => clearInterval(id);
  }, [data.seconds_active, data.state]);

  const formatDuration = (s: number) => {
    const h = Math.floor(s / 3600).toString().padStart(2, '0');
    const m = Math.floor((s % 3600) / 60).toString().padStart(2, '0');
    const sec = (s % 60).toString().padStart(2, '0');
    return `${h}:${m}:${sec}`;
  };

  if (data.state) {
    return (
      <div className="animate-banner-pulse border border-danger/50 rounded-lg p-4 md:p-5 flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <ShieldAlert className="w-8 h-8 text-danger animate-pulse-dot" />
          <div>
            <h2 className="text-lg md:text-xl font-bold text-danger">🚨 ACTIVE THREAT DETECTED</h2>
            <p className="text-xs text-muted-foreground">
              Session started: {formatIST(data.session_start)}
            </p>
          </div>
        </div>
        <div className="font-mono text-2xl md:text-3xl font-bold text-danger animate-count-pulse">
          {formatDuration(elapsed)}
        </div>
      </div>
    );
  }

  return (
    <div className="border border-safe/30 bg-safe/5 rounded-lg p-4 md:p-5 flex items-center gap-3">
      <ShieldCheck className="w-8 h-8 text-safe" />
      <div>
        <h2 className="text-lg md:text-xl font-bold text-safe">🟢 ALL CLEAR</h2>
        <p className="text-xs text-muted-foreground">No active threats detected</p>
      </div>
    </div>
  );
}
