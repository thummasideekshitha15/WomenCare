import { useRef, useEffect } from 'react';
import { Mic, Download, Play } from 'lucide-react';
import type { FirebaseData } from '@/hooks/useFirebaseData';
import { formatIST } from '@/lib/formatTime';

interface Props {
  data: FirebaseData;
  isNew: boolean;
}

export function AudioEvidence({ data, isNew }: Props) {
  const audioRef = useRef<HTMLAudioElement>(null);

  const clips = data.uploads?.audio
    ? Object.entries(data.uploads.audio).sort((a, b) => b[0].localeCompare(a[0]))
    : [];

  useEffect(() => {
    if (audioRef.current && data.latest_audio) {
      audioRef.current.load();
    }
  }, [data.latest_audio]);

  if (!data.latest_audio && clips.length === 0) {
    return (
      <div className="border border-border rounded-lg bg-card p-4">
        <h3 className="text-sm font-semibold text-muted-foreground flex items-center gap-2 mb-3">
          <Mic className="w-4 h-4" /> AUDIO EVIDENCE
        </h3>
        <div className="flex items-center justify-center bg-muted rounded-md py-8">
          <div className="text-center text-muted-foreground">
            <Mic className="w-10 h-10 mx-auto mb-2 opacity-30" />
            <p className="text-sm">Awaiting first recording...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`border rounded-lg bg-card p-4 ${data.state ? 'animate-pulse-danger border-danger/30' : 'border-border'}`}>
      <h3 className="text-sm font-semibold text-muted-foreground flex items-center gap-2 mb-3">
        <Mic className="w-4 h-4" /> AUDIO EVIDENCE
        {isNew && (
          <span className="ml-2 px-2 py-0.5 rounded text-xs font-bold bg-safe/20 text-safe border border-safe/30">
            New Recording
          </span>
        )}
      </h3>

      {data.latest_audio && (
        <div className="mb-4">
          <p className="text-xs text-muted-foreground mb-2">Latest Recording</p>
          <audio ref={audioRef} controls className="w-full h-10" preload="metadata">
            <source src={data.latest_audio} type="audio/mpeg" />
          </audio>
        </div>
      )}

      {clips.length > 0 && (
        <div className="space-y-1 max-h-48 overflow-y-auto">
          {clips.map(([ts, url]) => (
            <div
              key={ts}
              className="flex items-center justify-between gap-2 px-3 py-2 rounded-md bg-muted/50 hover:bg-muted transition-colors text-sm"
            >
              <div className="flex items-center gap-2 min-w-0">
                <Play className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
                <span className="text-xs text-muted-foreground truncate">{formatIST(ts)}</span>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                <audio controls preload="none" className="h-8 w-36">
                  <source src={url} type="audio/mpeg" />
                </audio>
                <a
                  href={url}
                  download
                  className="p-1.5 rounded hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors"
                  title="Download"
                >
                  <Download className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
