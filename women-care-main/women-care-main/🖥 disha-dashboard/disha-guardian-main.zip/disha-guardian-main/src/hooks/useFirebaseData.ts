import { useState, useEffect, useCallback, useRef } from 'react';

const FIREBASE_URL = 'https://women-safety-d12d5-default-rtdb.firebaseio.com/threat_detect.json';
const POLL_INTERVAL = 5000;

export interface FirebaseData {
  state: boolean;
  session_start: string;
  seconds_active: number;
  last_upload_time: string;
  latest_audio: string;
  latest_photo: string;
  live_location: {
    lat: number;
    lng: number;
    accuracy: number;
    maps_link: string;
    timestamp: string;
  } | null;
  uploads: {
    audio: Record<string, string>;
    photos: Record<string, string>;
  } | null;
}

export function useFirebaseData() {
  const [data, setData] = useState<FirebaseData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastFetch, setLastFetch] = useState<Date | null>(null);
  const prevPhotoRef = useRef<string | null>(null);
  const prevAudioRef = useRef<string | null>(null);
  const prevStateRef = useRef<boolean | null>(null);
  const [newPhoto, setNewPhoto] = useState(false);
  const [newAudio, setNewAudio] = useState(false);

  const fetchData = useCallback(async () => {
    try {
      const res = await fetch(FIREBASE_URL);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const json = await res.json();
      
      if (json) {
        const parsed: FirebaseData = {
          state: json.state ?? false,
          session_start: json.session_start ?? '',
          seconds_active: json.seconds_active ?? 0,
          last_upload_time: json.last_upload_time ?? '',
          latest_audio: json.latest_audio ?? '',
          latest_photo: json.latest_photo ?? '',
          live_location: json.live_location ?? null,
          uploads: json.uploads ?? null,
        };

        // Detect new photo
        if (prevPhotoRef.current && parsed.latest_photo && parsed.latest_photo !== prevPhotoRef.current) {
          setNewPhoto(true);
          setTimeout(() => setNewPhoto(false), 3000);
        }
        prevPhotoRef.current = parsed.latest_photo;

        // Detect new audio
        if (prevAudioRef.current && parsed.latest_audio && parsed.latest_audio !== prevAudioRef.current) {
          setNewAudio(true);
          setTimeout(() => setNewAudio(false), 3000);
        }
        prevAudioRef.current = parsed.latest_audio;

        // Detect threat state change
        if (prevStateRef.current === false && parsed.state === true) {
          if (Notification.permission === 'granted') {
            new Notification('🚨 Active threat detected — Disha Smart Monitor');
          }
        }
        prevStateRef.current = parsed.state;

        setData(parsed);
        setError(null);
      }
      setLastFetch(new Date());
    } catch (e: any) {
      setError(e.message || 'Failed to fetch');
    } finally {
      setLoading(false);
    }
  }, []);

  const forceRefresh = useCallback(() => {
    setLoading(true);
    fetchData();
  }, [fetchData]);

  useEffect(() => {
    // Request notification permission
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission();
    }
    fetchData();
    const interval = setInterval(fetchData, POLL_INTERVAL);
    return () => clearInterval(interval);
  }, [fetchData]);

  // Update page title based on threat state
  useEffect(() => {
    if (data) {
      document.title = data.state
        ? '🚨 [ACTIVE] Disha Smart Monitor'
        : '✅ Disha Smart Monitor';
    }
  }, [data?.state]);

  return { data, loading, error, lastFetch, forceRefresh, newPhoto, newAudio };
}
