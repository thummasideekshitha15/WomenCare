import { useFirebaseData } from '@/hooks/useFirebaseData';
import { DashboardHeader } from '@/components/dashboard/DashboardHeader';
import { ThreatBanner } from '@/components/dashboard/ThreatBanner';
import { LiveLocation } from '@/components/dashboard/LiveLocation';
import { PhotoEvidence } from '@/components/dashboard/PhotoEvidence';
import { AudioEvidence } from '@/components/dashboard/AudioEvidence';
import { StatsFooter } from '@/components/dashboard/StatsFooter';
import { formatIST } from '@/lib/formatTime';
import { Loader2 } from 'lucide-react';

const Index = () => {
  const { data, loading, error, forceRefresh, newPhoto, newAudio } = useFirebaseData();

  const handleExport = () => {
    if (!data) return;
    let report = '=== DISHA SMART MONITOR — Evidence Report ===\n';
    report += `Generated: ${new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })}\n`;
    report += `Threat State: ${data.state ? 'ACTIVE' : 'Clear'}\n`;
    report += `Session Start: ${formatIST(data.session_start)}\n`;
    report += `Seconds Active: ${data.seconds_active}\n\n`;

    if (data.live_location) {
      report += `--- GPS Location ---\n`;
      report += `Lat: ${data.live_location.lat}, Lng: ${data.live_location.lng}\n`;
      report += `Accuracy: ${data.live_location.accuracy}m\n`;
      report += `Maps: ${data.live_location.maps_link}\n\n`;
    }

    report += `--- Photo Evidence ---\n`;
    if (data.uploads?.photos) {
      Object.entries(data.uploads.photos)
        .sort((a, b) => b[0].localeCompare(a[0]))
        .forEach(([ts, url]) => {
          report += `[${formatIST(ts)}] ${url}\n`;
        });
    } else {
      report += 'No photos captured.\n';
    }

    report += `\n--- Audio Evidence ---\n`;
    if (data.uploads?.audio) {
      Object.entries(data.uploads.audio)
        .sort((a, b) => b[0].localeCompare(a[0]))
        .forEach(([ts, url]) => {
          report += `[${formatIST(ts)}] ${url}\n`;
        });
    } else {
      report += 'No audio captured.\n';
    }

    const blob = new Blob([report], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    window.open(url, '_blank');
  };

  if (loading && !data) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin text-police mx-auto mb-3" />
          <p className="text-sm text-muted-foreground">Connecting to Disha Smart...</p>
        </div>
      </div>
    );
  }

  if (error && !data) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center border border-danger/30 rounded-lg p-6 bg-card max-w-md">
          <p className="text-danger font-semibold mb-2">Connection Error</p>
          <p className="text-sm text-muted-foreground mb-4">{error}</p>
          <button
            onClick={forceRefresh}
            className="px-4 py-2 rounded-md bg-police text-police-foreground text-sm font-medium"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  if (!data) return null;

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <DashboardHeader data={data} onRefresh={forceRefresh} onExport={handleExport} />
      
      <main className="flex-1 p-4 md:p-6 space-y-4 max-w-[1600px] mx-auto w-full">
        {/* Section 1: Threat Banner */}
        <ThreatBanner data={data} />

        {/* Section 2 & 3: Location + Photos */}
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
          <div className="lg:col-span-2">
            <LiveLocation data={data} />
          </div>
          <div className="lg:col-span-3">
            <PhotoEvidence data={data} isNew={newPhoto} />
          </div>
        </div>

        {/* Section 4: Audio */}
        <AudioEvidence data={data} isNew={newAudio} />

        {/* Section 5: Stats */}
        <StatsFooter data={data} />
      </main>

      {error && (
        <div className="fixed bottom-4 right-4 px-3 py-2 rounded-md bg-alert/20 border border-alert/30 text-alert text-xs">
          Polling error: {error}
        </div>
      )}
    </div>
  );
};

export default Index;
